import React from "react";
import SignInForm from "../Components/SignUp";

function SignUp() {
  return (
    <div>
      <h2>
        <SignInForm />
      </h2>
    </div>
  );
}

export default SignUp;
