
import * as React from "react";
import LogInForm from "../Components/LoginForm";
// import { MyComponent  } from './Style';

function SignIn() {
  return (
    <>
      <LogInForm />
    </>
  );
}

export default SignIn;
